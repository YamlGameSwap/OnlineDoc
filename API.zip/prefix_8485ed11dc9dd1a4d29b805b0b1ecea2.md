纸张 NFT 的查询有两处。

- 链上查询
- 链下查询

## 链上查询

链上查询需要前端自己访问区块链网络进行查询。

## 链下查询

相关 API 如下

|参数|说明|
|---|---|
|URL|xxx.com/paper/get|
|method|POST|

参数说明

|参数|类型|数值|说明|
|---|---|---|---|
|type|int|3001|用户行为：查询链下纸张 NFT 数量|

response 返回

- 成功返回

```
response: {
	code: ?,
	status: success,
	msg: "?",
	data: {
		"offline_number":"",
	}
}
```

|参数|类型|数值|说明|
|---|---|---|---|
|offline_number|int|?|用户链下有多少个纸张 NFT|