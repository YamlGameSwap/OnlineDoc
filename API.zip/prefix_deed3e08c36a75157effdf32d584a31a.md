# <center>收藏</center>

收藏只针对游戏本整体，其有两种行为。某一游戏本具体收藏量，查看游戏本相关 API。

- 收藏
- 取消收藏

## 收藏

收藏流程图。

![](http://47.122.21.202:4999/server/index.php?s=/api/attachment/visitFile&sign=e27bd35a5fa0a64feb055ab009332157)

后端需要注意的是，存储用户每一个收藏，并且将 status 置为 1。

相关 API 如下。

|参数|说明|
|---|---|
|URL|xxx.com/book/collect|
|method|POST|

相关参数

|参数|类型|数值|说明|
|---|---|---|---|
|type|int|1003|用户行为：收藏|
|book_token|String|?|游戏本 token|

response 返回

- 成功返回

```
response: {
	code: ?,
	status: success,
	msg: "收藏成功",
	data: {
		"collect": 100,
	}
}
```

- 返回失败

```
response: {
	code: ?,
	status: fail/error,
	msg: "收藏失败",
	data: {}
}
```

## 取消点赞

取消收藏的流程和点赞一样。

后端需要注意的是，取消的时候，并不是把数据库中的数据删除，而是将 status 置为 0。

相关 API 如下。

|参数|说明|
|---|---|
|URL|xxx.com/book/collect|
|method|DELETE|

相关参数

|参数|类型|数值|说明|
|---|---|---|---|
|type|int|1004|用户行为：取消收藏|
|book_token|String|?|书籍唯一 token|

response 返回

- 成功返回

```
response: {
	code: ?,
	status: success,
	msg: "取消收藏成功",
	data: {
		"collect": 100,
	}
}
```

- 返回失败

```
response: {
	code: ?,
	status: fail/error,
	msg: "取消收藏失败",
	data: {}
}
```

参数说明

|参数|类型|数值|说明|
|---|---|---|---|
|collect|int|?|该游戏本的收藏数|
