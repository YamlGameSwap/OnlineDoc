两次请求

相关 API 如下

|参数|说明|
|---|---|
|URL|xxx.com/market/purchase|
|method|POST|

参数说明

|参数|类型|数值|说明|
|---|---|---|---|
|version|int|?|第几次请求|
|NFT_token|String|?|NFT token|
|token_id|int|?|NFT token id|
|market_type|int|?|市场类型<br/>0 出租 <br/> 1 出售|

- 前端传递参数到后端
- 后端拿到后返回 auth 和 code
- 前端连接区块链，进行交互
- 前端进行等待，提示用户不要离开
- 成功后，对后端进行二次请求

response 返回

- 成功返回

```
response: {
	code: ?,
	status: success,
	msg: "?",
	data: {
		"contract":"",
		"auth":"",
		"code":"",
	}
}
```

相关参数

|参数|类型|数值|说明|
|---|---|---|---|
|contract|string|?|合约地址|
|auth|byte|?|合约校验数|
|code|byte|?|合约数据|

第二次请求后，后端进行数据库更新。