# <center>存储</center>

存储有下面几种场景

1. 存储游戏本基本信息
1. 存储章节剧本草稿箱

## 存储游戏本基本信息

流程图如下

相关 API 如下

|参数|说明|
|---|---|
|URL|xxx.com/book/set|
|method|POST|

相关参数

|参数|类型|数值|说明|
|---|---|---|---|
|book_title|String|?|游戏本标题|
|book_url|String|?|游戏本封面 URL|
|book_summary|String|?|游戏本简介|

response 返回。

- 成功返回

```
response: {
	code: ?,
	status: success,
	msg: "?",
	data: {
			"book_token":"",
			"book_title":"",
			"book_url":"",
			"book_summary":"",
			"drafts":true,
	}
}
```

## 存储章节剧本草稿箱

流程图如下

相关 API 如下

|参数|说明|
|---|---|
|URL|xxx.com/section/set|
|method|POST|

相关参数

|参数|类型|数值|说明|
|---|---|---|---|
|type|int|2052|用户行为：游戏本章节存储|
|book_token|String|?|游戏本 token|
|section_title|String|?|章节标题|
|section_token|String|?|章节 token|
|section_content|String|?|章节剧本|

如果是新创建的章节，那么 section_token 为空。

response 返回。

- 成功返回

```
response: {
	code: ?,
	status: success,
	msg: "?",
	data: {
	}
}
```
