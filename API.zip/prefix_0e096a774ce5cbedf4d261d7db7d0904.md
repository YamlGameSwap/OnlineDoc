## 用户 User

```
String nickName; // 暂时预留
String UserAddress;// 钱包地址
String UserToken;//用户唯一识别 token 长度为 128 位
String passWord;//用户密码 长度小于 16
```

## 点赞 Like

```
String UserToken; // 用户唯一识别 token
String book; // 书籍唯一识别 token
boolean status; // 是否点赞
```

## 收藏 Collect

```
String userToken; // 用户唯一识别 token
String book; // 书籍唯一识别 token
boolean status; // 是否收藏
```

## 游戏本弹幕 Danmu

```
String userToken; // 对应 User 的 token
String book;  // 游戏本的 token
String section; // 游戏本章节唯一识别 token
String comment; // 弹幕内容
```

## 游戏本评论

```
String userToken; // 对应 User 的 token
String book;  // 游戏本的 token
String comment; // 评论内容
```

## 游戏本 GameBook

```
String bookTitle;//游戏本标题
String bookSummary;//游戏本的简介
String userToken; // 对应 User 的 token
String bookToken; // 游戏本唯一标识
int bookType; // 书籍类别
String bookUrl; // 书籍封面 URL
int like; // 喜欢数
int unlike; // 讨厌数
int collect; // 收藏数
int engineCode; // 引擎编号
boolean exist; // 游戏本是否删除
boolean drafts; // 游戏本是否在草稿箱还是发布
boolean bad; // 是否为烂剧本
String badMsg; // 烂剧本的理由
```

## 游戏本章节 「每一个游戏本里面有多个章节」

```
String bookToken;  // 游戏本的 token
String sectionToken; // 该章节的 token
int order; // 第几章节
String sectionContent; // 章节内容
```

## 纸张 NFT

```
String userToken; // 对应 User 的 token
String userAddress; // 对应 User 的地址
int offline_number;// 链下纸张数量
int actionCode; // 行为
boolean status;//该行为下的纸张是否被上链
```

## 游戏本 NFT

```
String userToken; // 对应 User 的 token
String bookToken; //游戏本 token
int originRent; // NFT 初始随机等级
String NFTToken; // NFT 合约地址
String NFTName; // NFT 名称
String NFTUrl;// NFT 图片存储 URL
double NFTPrice; // NFT 价格
int NFTOriginNumber; // NFT 初始数量
boolean isChain;// 上链是否成功
int chainCode; // 主链代码
```
