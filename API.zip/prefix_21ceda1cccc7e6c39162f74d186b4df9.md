mint 是用户将链下纸张 NFT，进行上链。

相关 API 如下

|参数|说明|
|---|---|
|URL|xxx.com/paper/mint|
|method|POST|

参数说明

|参数|类型|数值|说明|
|---|---|---|---|
|type|int|3003|用户行为：纸张 NFT mint|
|version|int|?|第一次请求为 1，第二次请求为2|
|status|boolean|?|检测是否上链成功。「二次请求需要」|

相关流程如下

1. 前端进行请求
2. 后端进行数据库校验，拿到所有 status = 0 的纸张 NFT
3. 将所有的 status 置为 1
4. 将上链 code 进行返回
5. 前端拿到 code 后进行数据库调用
6. 前端等待 penging，「并提醒用户不要离开页面」
7. 接收到区块链数据后，再次请求后端
8. 后端拿到数据需要查看是否成功，再对数据库做决定

所以，建议数据库的积分状态一共有两个

- tmp_status
- status

当第一次请求发来，tmp_status = 1，第二次请求成功则 status = 1

response 返回

第一次请求返回

- 成功返回

```
response: {
	code: ?,
	status: success,
	msg: "?",
	data: {
		"code":"",
	}
}
```

相关参数

|参数|类型|数值|说明|
|---|---|---|---|
|code|byte|?|合约数据|

第二次请求返回

- 成功返回

```
response: {
	code: ?,
	status: success,
	msg: "?",
	data: {
	}
}
```