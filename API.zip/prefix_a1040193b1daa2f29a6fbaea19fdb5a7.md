- 按分类查询
- 按 NFT token 搜索

## 按照分类搜索
## 按照 NFT Token 搜索

相关 API 如下

|参数|说明|
|---|---|
|URL|xxx.com/market/get|
|method|GET|

参数说明

|参数|类型|数值|说明|
|---|---|---|---|
|book_type|int|?|书籍类型|
|NFT_token|String|?|NFT token|
|market_type|int|?|市场类型<br/>0 出租 <br/> 1 出售|

NFTToken 如果存在就说明是按照 NFT Token 搜索，如果没有，说明是按照类型搜索

价格按照从低到高的顺序排列。

response 返回

- 成功返回

```
response: {
	code: ?,
	status: success,
	msg: "?",
	data: {
		1:{
			"book_title":"",
			"book_token":"",
			"book_url":"",
			"NFT_token":"",
			"token_id":"",
			"price":0,
		},
		2:{}
	}
}
```

相关参数

|参数|类型|数值|说明|
|---|---|---|---|
|book_title|String|?|书籍名字|
|book_token|String|?|书籍 token|
|book_url|String|?|书籍图片 URL|
|NFT_token|String|?|NFT 合约地址|
|token_id|int|?|NFT token id|
|price|double|?|价格|

