发布一共有两个场景。

- 免费
- 上链

相关 API 如下

|参数|说明|
|---|---|
|URL|xxx.com/book/push|
|method|POST|

相关参数

|参数|类型|数值|说明|
|---|---|---|---|
|book_token|String|?|游戏本 token|
|NFT_name|String|?|NFT 名字，免费本不赋值|
|NFT_number|int|?|发布多少个 NFT，免费本不赋值|
|NFT_url|String|?|NFT 存储 URL，免费本不赋值|
|NFT_price|double|?|NFT mint 价格，免费本不赋值|
|chain_code|int|?|具体上链哪个主链，免费本不赋值|
|NFT_token|String|?|NFT 合约地址，二次请求需要|
|chainStatus|int|?|1:上链成功<br/>2:上链失败<br/>二次请求需要|

前端处理流程

- 判断是免费本还是上链本
- 如果是上链本的话，需要查询是否有平台 NFT
- 拥有平台 NFT 的人可以对 mint 的初始值适量扩大

后端处理流程

- 后端接收到后，判断参数是否符合规范
	- 收费本必须超过 12 章节，免费本最小为 6 章节
- 判断游戏本是免费还是上链，上链后
- 获取用户的 token，拿到用户的 address 后
- 生成合约代码，返回给前端
- 前端拿到合约后，调用小狐狸进行上链请求
- 这个是否总共会发生下面的场景
	- 用户取消
	- 用户提交，失败
	- 用户提交成功
- 无论哪种场景，前端需要再给后端发一次请求。

黑客还是会伪造 API 参数，进行攻击，比如调整 NFT mint 的初始值。所以，NFT mint 的最大值也是有上限的，这样即便是被攻击了，损失也不大。

response 返回

第一次请求返回

- 成功返回

```
response: {
	code: ?,
	status: success,
	msg: "?",
	data: {
		"code":"",
	}
}
```

相关参数

|参数|类型|数值|说明|
|---|---|---|---|
|code|byte|?|合约数据|

第二次请求返回

- 成功返回

```
response: {
	code: ?,
	status: success,
	msg: "?",
	data: {
	}
}
```