# <center>评论</center>

评论不能超过 200 字。

用户评论功能如下:

- 添加
- 删除

评论没有查询功能，该功能集成在游戏本 API 中。

## 添加

评论添加的流程图如下

![](http://47.122.21.202:4999/server/index.php?s=/api/attachment/visitFile&sign=41d00ad9c3e0d0c68c795d553f4a79ed)

需要注意的是「后端返回信息」。当成功后，后端在 response 中的 data 中返回 ? 条评论，最新的一条即是刚才评论的那条。

一个用户对于同一个游戏本，不能短时间大量评论。一般来说 6 小时评论一次。删除后，可以刷新该评论。

后端相关行为

- 查询 6 小时内，该 IP 是否评论了该游戏本，没有
- 检测长度是否合规，通过
- 存库，返回

相关 API 如下

|参数|说明|
|---|---|
|URL|xxx.com/book/comment|
|method|POST|

相关参数

|参数|类型|数值|说明|
|---|---|---|---|
|book_token|String|?|游戏本的 token|
|comment|String|?|评论|

response 返回

- 成功返回

```
response: {
	code: ?,
	status: success,
	msg: "评论添加成功",
	data:{
		comment_count:0,
		comments: {
			"1":"",
			"2":"",
			"3":"",
		}
	}
}
```

弹幕最多有 50 条。

- 返回失败

```
response: {
	code: ?,
	status: fail/error,
	msg: "?",
	data: {}
}
```

|参数|类型|数值|说明|
|---|---|---|---|
|comment_count|int|?|一共有多少条评论|
|comments|json|?|评论，按照日期倒序排列|

## 删除 「预留」