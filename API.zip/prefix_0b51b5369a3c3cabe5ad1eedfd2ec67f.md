查询一共分为下面几类

- 查询详情
	- 查询某一本详情
	- 查询某一本的某一章节的详情
- 查询某一类
- 模糊搜索

## 查询某一本详情

相关 API 如下

|参数|说明|
|---|---|
|URL|xxx.com/book/get|
|method|GET|

相关参数

|参数|类型|数值|说明|
|---|---|---|---|
|book_token|String|?|游戏本 token|
|page|int|?|评论第几页|

评论一次最多返回 20 条，根据 page 来进行递增。

response 返回

- 成功返回

```
response: {
	code: ?,
	status: success,
	msg: "?",
	data: {
		"like": 200,
		"collect": 300,
		"book_type":1,
		"book_token":"",
		"book_title":"",
		"book_summary":"",
		"user_address":"",
		"NFT_token":"",
		"NFT_name":"",
		"NFT_origin_number":0,
		"NFT_chain_number":0,
		"NFT_url":"",
		"engine_code":0,
		"chain_code":0,
		"comment_count":0,
		"comment":{
			"1":"",
			"2":"",
			"3":"",
			... ...
		},
		"section_count":0,
		"section":{
			"1":{
				"section_title":"",
				"section_token":"",
			},
			"2":...,
			...
		}
	}
}
```

- 返回失败

```
response: {
	code: ?,
	status: fail/error,
	msg: "?",
	data: {}
}
```

参数说明

|参数|类型|数值|说明|
|---|---|---|---|
|like|int|?|该游戏本的点赞数|
|collect|int|?|该游戏本的收藏数|
|book_type|int|?|该游戏本的类型|
|book_token|String|?|该游戏本的唯一token|
|book_title|String|?|游戏本的标题|
|book_url|String|?|游戏本的 URL|
|book_summary|String|?|游戏本的简介|
|user_address|String|?|作者的钱包地址|
|NFT_token|String|?|NFT 合约地址|
|NFT_name|String|?|NFT名字|
|NFT_origin_number|int|?|NFT 初始数量|
|NFT_chain_number|int|?|NFT 链上数量|
|NFT_url|String|?|NFT 图片存储 URL|
|engine_code|int|?|引擎编号|
|chain_code|int|?|主链编号|
|comment_count|int|?|一共有多少个评论|
|comment|json|?|评论|
|section_count|int|?|章节数量|
|section_title|String|?|章节标题|
|section_token|String|?|章节 token|

如果有 NFT 信息，就证明这是一个付费本。

## 查询某一本中某一章节详情

查询某一章节的详情，需要分为两个情况

- 免费章节
- 付费章节

相关流程图如下

前端的验证流程如下

- 判断是否是免费还是付费章节，如果是付费章节
- 前端通过调用区块链，判断该钱包是否有此 NFT 的权限，通过后
- 发送数据

相关 API 如下

|参数|说明|
|---|---|
|URL|xxx.com/book/section|
|method|GET|

相关参数

|参数|类型|数值|说明|
|---|---|---|---|
|book_token|String|?|游戏本 token|
|section_token|String|?|游戏本章节 token|

该请求，还是存在被攻击的可能性，但是，由于是非安全信息，所以，受灾程度可以忍受，通过 headers 中的 auth 判断即可。

response 返回

- 成功返回

```
response: {
	code: ?,
	status: success,
	msg: "?",
	data: {
		"engine_code":0,
		"yaml":"",
		"danmus":{
			"1":"",
			"2":"",
			"3":"",
			... ...
		}
	}
}
```

- 返回失败

```
response: {
	code: ?,
	status: fail/error,
	msg: "?",
	data: {}
}
```

参数说明

|参数|类型|数值|说明|
|---|---|---|---|
|engine_code|int|?|引擎代码|
|yaml|String|?|剧本内容|
|danmus|json|?|弹幕|

## 查询所有用户的某一类/查询自己的所有

并且，有两个场景，用户查询自己，用户查询他人 + 自己。

相关 API 如下

|参数|说明|
|---|---|
|URL|xxx.com/book/collect|
|method|GET|

相关参数

|参数|类型|数值|说明|
|---|---|---|---|
|page|int|?|第几页，不填写为 0 页|
|drafts|boolean|?|是否查询草稿箱|
|user_token|String|?|用户唯一识别 token|
|book_type|int|?|书籍类别|
|book_status|int|?|书籍状态|

- 这个 user_token 要写在参数里，这样区分查询所有用户还是只查询自己用户
- 如果 user_token 有值，则证明查询该用户下的书籍，不区分分类，如果，没有值，则证明查询该分类下的所有的书籍
	- drafts 只有在有 user_token 的时候才有效
	- 在 user_token 存在的情况下，默认 bad 为 true，即会返回坏剧本，如果，user_token 不存在，则 bad 为 false，不会返回坏剧本
- 如果 book_type 有值，则证明查询某一类别的书籍，该值和 user_token 不兼容，user_token 优先级最高
- book_status 游戏本状态，草稿箱/已发布/坏剧本。该值和 user_token 成对出现

response 返回

- 成功返回

```
response: {
	code: ?,
	status: success,
	msg: "?",
	data: {
		"1":{
			"book_token":"",
			"book_title":"",
			"book_url":"",
			"bad_msg":"",
			"like":0,
			"collect":0,
			"book_status":1,
			"NFT_token":"",
		}
	}
}
```

参数说明

|参数|类型|数值|说明|
|---|---|---|---|
|like|int|?|该游戏本的点赞数|
|collect|int|?|该游戏本的收藏数|
|book_token|String|?|该游戏本的唯一token|
|book_title|String|?|游戏本的标题|
|book_url|String|?|游戏本的封面 URL|
|badMsg|String|?|烂剧本的理由|
|book_status|int|?|游戏本状态已发布/草稿箱/坏剧本|
|NFT_token|String|?|游戏本的 NFT 合约地址，用来判断是否上链|

## 模糊查询

目前只支持查询游戏本名字。

相关 API 如下

|参数|说明|
|---|---|
|URL|xxx.com/book/search|
|method|GET|

相关参数

|参数|类型|数值|说明|
|---|---|---|---|
|page|int|?|第几页，不填写为 0 页|
|book_title|string|?|游戏本名称|

response 返回

- 成功返回

```
response: {
	code: ?,
	status: success,
	msg: "?",
	data: {
		"1":{
			"book_token":"",
			"book_title":"",
			"book_url":"",
			"like":0,
			"collect":0,
		}
	}
}
```

参数说明

|参数|类型|数值|说明|
|---|---|---|---|
|like|int|?|该游戏本的点赞数|
|collect|int|?|该游戏本的收藏数|
|book_token|String|?|该游戏本的唯一token|
|book_title|String|?|游戏本的标题|
|book_url|String|?|游戏本的封面 URL|