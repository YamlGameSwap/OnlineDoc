当游戏本 NFT 达到 50 级之后，会开启印刷功能。

二次请求。

每个游戏本 NFT 可以 1 个星期印刷一次或者 NFT 级别回退几个级别【该方案未定】

相关 API 如下

|参数|说明|
|---|---|
|URL|xxx.com/book/print|
|method|POST|

相关参数

|参数|类型|数值|说明|
|---|---|---|---|
|version|int|?|第几次请求|
|NFT_token|String|?|NFT 合约地址|
|token_id|int|?|NFT token id <br/>第一次请求，这个参数表示要印刷的 id<br/>第二次请求，这个参数表示产生的 NFT id|

response 返回

- 成功返回

```
response: {
	code: ?,
	status: success,
	msg: "?",
	data: {
		"contract":"",
		"auth":"",
		"code":"",
	}
}
```

相关参数

|参数|类型|数值|说明|
|---|---|---|---|
|contract|string|?|合约地址|
|auth|byte|?|合约检验|
|code|byte|?|合约数据|

第二次请求表明已经印刷成功。所以，需要更新数据库。
