# <center>点赞</center>

点赞只针对游戏本整体，其有两种行为。某一游戏本具体点赞量，查看游戏本相关 API。

- 点赞
- 取消点赞

## 点赞

点赞流程图。

![](http://47.122.21.202:4999/server/index.php?s=/api/attachment/visitFile&sign=a276e771b3b28b8ca97d1eb39448e2d6)

后端需要注意的是，存储用户每一个赞，并且将 status 置为 1。

相关 API 如下。

|参数|说明|
|---|---|
|URL|xxx.com/book/like|
|method|POST|

相关参数

|参数|类型|数值|说明|
|---|---|---|---|
|type|int|1001|用户行为：点赞|
|book_token|String|?|游戏本 token|

response 返回

- 成功返回

```
response: {
	code: ?,
	status: success,
	msg: "点赞成功",
	data: {
		"like": 100,
	}
}
```

- 返回失败

```
response: {
	code: ?,
	status: fail/error,
	msg: "点赞失败",
	data: {}
}
```

## 取消点赞

取消点赞的流程和点赞一样。

后端需要注意的是，取消的时候，并不是把数据库中的数据删除，而是将 status 置为 0。

相关 API 如下。

|参数|说明|
|---|---|
|URL|xxx.com/book/like|
|method|DELETE|

相关参数

|参数|类型|数值|说明|
|---|---|---|---|
|type|int|1002|用户行为：取消点赞|
|book_token|String|?|游戏本 token|

response 返回

- 成功返回

```
response: {
	code: ?,
	status: success,
	msg: "取消点赞成功",
	data: {
		"like": 200,
	}
}
```

- 返回失败

```
response: {
	code: ?,
	status: fail/error,
	msg: "取消点赞失败",
	data: {}
}
```

参数说明

|参数|类型|数值|说明|
|---|---|---|---|
|like|int|?|该游戏本的点赞数|