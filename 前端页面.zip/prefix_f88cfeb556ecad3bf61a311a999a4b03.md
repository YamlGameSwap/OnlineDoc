游戏本编辑，「二级页面」

- 从 [游戏本展示「个人」 草稿箱](/web/#/14/90) 进入

## 编辑

- 标题
- 内容
- 技巧「固定页面，就是如何写剧本的技巧」

左边是章节，通过点击 + 号来生成新的章节。

章节是每 30 秒自动保存一次，也可以手动保存，通过点击「保存」按钮。

➕ 号下面是发布页面。发布主要是和 NFT 相关的，需要的信息有

API

- [存储章节剧本草稿箱 | xxx.com/section/set](/web/#/11/65)

![](http://47.122.21.202:4999/server/index.php?s=/api/attachment/visitFile&sign=6f711c1baaafefe3368a264f8d5fbc21)

## 发布

- 图片上传
	- IPFS
	- 图片的尺寸必须是固定的「尺寸待定」，所以，要进行用户主动切割。
	- 只有 IPFS 上传成功后，图片才进行展示
	
免费发布，就是和合约无关，付费发布，就是该游戏本要发布游戏本 NFT。

API

- [发布 | xxx.com/book/push](/web/#/11/66)

![](http://47.122.21.202:4999/server/index.php?s=/api/attachment/visitFile&sign=03d0ed0fb5cb4bca97ba9d9415f32ed2)