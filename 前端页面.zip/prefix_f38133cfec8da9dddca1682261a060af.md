NFT 信息「个人」。

每页最多 20 条。

- 点击游戏本名称，可以跳转到 [游戏本 play](/web/#/14/93) 页面

状态有

- 出售
- 出租
- 自持
- 出售/出租 1/3

出售和出租并不冲突。

- 出售 状态
	- 可出租
	- 可升级
	- 可下架
	- 不可重复出售
- 出租 状态
	- 可出售
	- 可升级
	- 可下架
	- 未满不可出租
- 自持
	- 可出售
	- 可出租
	- 可升级
	- 可下架

![](http://47.122.21.202:4999/server/index.php?s=/api/attachment/visitFile&sign=9986c7e00e6c722aa1aa01e053244ca6)

![](http://47.122.21.202:4999/server/index.php?s=/api/attachment/visitFile&sign=f16465cfc5effda329653dc6ffb45925)

![](http://47.122.21.202:4999/server/index.php?s=/api/attachment/visitFile&sign=f97bca95cdd6e52f99ccb0afdb484810)

## 出售

![](http://47.122.21.202:4999/server/index.php?s=/api/attachment/visitFile&sign=fc640f9492ee25431503d3ce09ff53b1)

## 出租

出租，是一次性出租所有未出租的名额。

出租信息并不上链。但是，要和合约交互，进行抽税。

如果，有出租信息，需要先进行下架，然后重新出租。

特殊情况，如果，我的出租名额有 5，现在已经有人租赁了 1 个了，我还剩 4 个名额。要是想更改出租价格的话，需要先 下架 出租「4 个」，然后重新提交价格 「4 个」。

暂时规定出租为 1 星期。

![](http://47.122.21.202:4999/server/index.php?s=/api/attachment/visitFile&sign=1bc43fbe9afd4eb0a42d701da1130e8f)

## 升级

![](http://47.122.21.202:4999/server/index.php?s=/api/attachment/visitFile&sign=0e1796efc37d53bf8d907eefe213a380)

## 下架

![](http://47.122.21.202:4999/server/index.php?s=/api/attachment/visitFile&sign=39d9ad860f614104d8f32552b5cef614)
